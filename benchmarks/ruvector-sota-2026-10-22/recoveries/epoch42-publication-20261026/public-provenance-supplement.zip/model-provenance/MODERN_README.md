---
library_name: transformers
base_model:
- answerdotai/ModernBERT-large
license: apache-2.0
language:
- en
pipeline_tag: zero-shot-classification
datasets:
- nyu-mll/glue
- facebook/anli
tags:
- instruct
- natural-language-inference
- nli
---

# Model Card for Model ID

This model is ModernBERT multi-task fine-tuned on tasksource NLI tasks, including MNLI, ANLI, SICK, WANLI, doc-nli, LingNLI, FOLIO, FOL-NLI, LogicNLI, Label-NLI and all datasets in the below table).
This is the equivalent of an "instruct" version.
The model was trained for 200k steps on an Nvidia A30 GPU.

It is very good at reasoning tasks (better than llama 3.1 8B Instruct on ANLI and FOLIO), long context reasoning, sentiment analysis and zero-shot classification with new labels. 

The following table shows model test accuracy. These are the scores for the same single transformer with different classification heads on top.
Further gains can be obtained by fine-tuning on a single-task, e.g. SST, but it this checkpoint is great for zero-shot classification and natural language inference (contradiction/entailment/neutral classification).

| test_name                             |   test_accuracy |
|:--------------------------------------|----------------:|
| glue/mnli                             |            0.89 |
| glue/qnli                             |            0.96 |
| glue/rte                              |            0.91 |
| glue/wnli                             |            0.64 |
| glue/mrpc                             |            0.81 |
| glue/qqp                              |            0.87 |
| glue/cola                             |            0.87 |
| glue/sst2                             |            0.96 |
| super_glue/boolq                      |            0.66 |
| super_glue/cb                         |            0.86 |
| super_glue/multirc                    |            0.9  |
| super_glue/wic                        |            0.71 |
| super_glue/axg                        |            1    |
| anli/a1                               |            0.72 |
| anli/a2                               |            0.54 |
| anli/a3                               |            0.55 |
| sick/label                            |            0.91 |
| sick/entailment_AB                    |            0.93 |
| snli                                  |            0.94 |
| scitail/snli_format                   |            0.95 |
| hans                                  |            1    |
| WANLI                                 |            0.77 |
| recast/recast_ner                     |            0.85 |
| recast/recast_sentiment               |            0.97 |
| recast/recast_verbnet                 |            0.89 |
| recast/recast_megaveridicality        |            0.87 |
| recast/recast_verbcorner              |            0.87 |
| recast/recast_kg_relations            |            0.9  |
| recast/recast_factuality              |            0.95 |
| recast/recast_puns                    |            0.98 |
| probability_words_nli/reasoning_1hop  |            1    |
| probability_words_nli/usnli           |            0.79 |
| probability_words_nli/reasoning_2hop  |            0.98 |
| nan-nli                               |            0.85 |
| nli_fever                             |            0.78 |
| breaking_nli                          |            0.99 |
| conj_nli                              |            0.72 |
| fracas                                |            0.79 |
| dialogue_nli                          |            0.94 |
| mpe                                   |            0.75 |
| dnc                                   |            0.91 |
| recast_white/fnplus                   |            0.76 |
| recast_white/sprl                     |            0.9  |
| recast_white/dpr                      |            0.84 |
| add_one_rte                           |            0.94 |
| paws/labeled_final                    |            0.96 |
| pragmeval/pdtb                        |            0.56 |
| lex_glue/scotus                       |            0.58 |
| lex_glue/ledgar                       |            0.85 |
| dynasent/dynabench.dynasent.r1.all/r1 |            0.83 |
| dynasent/dynabench.dynasent.r2.all/r2 |            0.76 |
| cycic_classification                  |            0.96 |
| lingnli                               |            0.91 |
| monotonicity-entailment               |            0.97 |
| scinli                                |            0.88 |
| naturallogic                          |            0.93 |
| dynahate                              |            0.86 |
| syntactic-augmentation-nli            |            0.94 |
| autotnli                              |            0.92 |
| defeasible-nli/atomic                 |            0.83 |
| defeasible-nli/snli                   |            0.8  |
| help-nli                              |            0.96 |
| nli-veridicality-transitivity         |            0.99 |
| lonli                                 |            0.99 |
| dadc-limit-nli                        |            0.79 |
| folio                                 |            0.71 |
| tomi-nli                              |            0.54 |
| puzzte                                |            0.59 |
| temporal-nli                          |            0.93 |
| counterfactually-augmented-snli       |            0.81 |
| cnli                                  |            0.9  |
| boolq-natural-perturbations           |            0.72 |
| equate                                |            0.65 |
| logiqa-2.0-nli                        |            0.58 |
| mindgames                             |            0.96 |
| ConTRoL-nli                           |            0.66 |
| logical-fallacy                       |            0.38 |
| cladder                               |            0.89 |
| conceptrules_v2                       |            1    |
| zero-shot-label-nli                   |            0.79 |
| scone                                 |            1    |
| monli                                 |            1    |
| SpaceNLI                              |            1    |
| propsegment/nli                       |            0.92 |
| FLD.v2/default                        |            0.91 |
| FLD.v2/star                           |            0.78 |
| SDOH-NLI                              |            0.99 |
| scifact_entailment                    |            0.87 |
| feasibilityQA                         |            0.79 |
| AdjectiveScaleProbe-nli               |            1    |
| resnli                                |            1    |
| semantic_fragments_nli                |            1    |
| dataset_train_nli                     |            0.95 |
| nlgraph                               |            0.97 |
| ruletaker                             |            0.99 |
| PARARULE-Plus                         |            1    |
| logical-entailment                    |            0.93 |
| nope                                  |            0.56 |
| LogicNLI                              |            0.91 |
| contract-nli/contractnli_a/seg        |            0.88 |
| contract-nli/contractnli_b/full       |            0.84 |
| nli4ct_semeval2024                    |            0.72 |
| biosift-nli                           |            0.92 |
| SIGA-nli                              |            0.57 |
| FOL-nli                               |            0.79 |
| doc-nli                               |            0.81 |
| mctest-nli                            |            0.92 |
| natural-language-satisfiability       |            0.92 |
| idioms-nli                            |            0.83 |
| lifecycle-entailment                  |            0.79 |
| MSciNLI                               |            0.84 |
| hover-3way/nli                        |            0.92 |
| seahorse_summarization_evaluation     |            0.81 |
| missing-item-prediction/contrastive   |            0.88 |
| Pol_NLI                               |            0.93 |
| synthetic-retrieval-NLI/count         |            0.72 |
| synthetic-retrieval-NLI/position      |            0.9  |
| synthetic-retrieval-NLI/binary        |            0.92 |
| babi_nli                              |            0.98 |



# Usage

## [ZS] Zero-shot classification pipeline
```python
from transformers import pipeline
classifier = pipeline("zero-shot-classification",model="tasksource/ModernBERT-large-nli")

text = "one day I will see the world"
candidate_labels = ['travel', 'cooking', 'dancing']
classifier(text, candidate_labels)
```
NLI training data of this model includes [label-nli](https://huggingface.co/datasets/tasksource/zero-shot-label-nli), a NLI dataset specially constructed to improve this kind of zero-shot classification.

## [NLI] Natural language inference pipeline

```python
from transformers import pipeline
pipe = pipeline("text-classification",model="tasksource/ModernBERT-large-nli")
pipe([dict(text='there is a cat',
  text_pair='there is a black cat')]) #list of (premise,hypothesis)
```

## Backbone for further fune-tuning

This checkpoint has stronger reasoning and fine-grained abilities than the base version and can be used for further fine-tuning.

# Citation

```
@inproceedings{sileo-2024-tasksource,
    title = "tasksource: A Large Collection of {NLP} tasks with a Structured Dataset Preprocessing Framework",
    author = "Sileo, Damien",
    booktitle = "Proceedings of the 2024 Joint International Conference on Computational Linguistics, Language Resources and Evaluation (LREC-COLING 2024)",
    month = may,
    year = "2024",
    address = "Torino, Italia",
    publisher = "ELRA and ICCL",
    url = "https://aclanthology.org/2024.lrec-main.1361",
    pages = "15655--15684",
}
```