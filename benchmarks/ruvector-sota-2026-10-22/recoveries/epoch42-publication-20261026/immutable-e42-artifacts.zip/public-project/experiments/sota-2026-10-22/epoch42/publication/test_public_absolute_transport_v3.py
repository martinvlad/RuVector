"""One unrelated public-path validator fixture; no production modes/private body."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
HERE=Path(__file__).resolve().parent
support=HERE.parents[3]/'fixture-support/publication'
sys.path.insert(0,str(support if support.is_dir()else HERE))
import importlib.util,json,copy,tempfile,unittest
TARGET=HERE.parent/'preparation/reviewed_build_results_transport_v3.py'
spec=importlib.util.spec_from_file_location('public_transport_fixture',TARGET);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)

class ExactPublicAbsolute(unittest.TestCase):
 def test_exact_two_roles_preserve_original_and_refuse_spoofs(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp)/'project';folder=root/'experiments/sota-2026-10-22/audit/epoch42';folder.mkdir(parents=True)
   roles={'admission':'GOLD_ADMISSION.json','protocol':'protocol.json'}
   for role,name in roles.items():
    file=folder/name;file.write_bytes(json.dumps({'invented_public_fixture':role}).encode())
   for role,name in roles.items():
    rel='experiments/sota-2026-10-22/audit/epoch42/'+name;row=helper.c.ref(root,rel);row['path']=str(folder/name);before=copy.deepcopy(row)
    self.assertIs(helper.checked_evidence(root,{},role,row),row);self.assertTrue(helper.c.same_fact(row,before))
    for badrole,badrow in [('other_public_role',row),(role,dict(row,path=str(Path(tmp)/name))),(role,dict(row,sha256='0'*64)),(role,dict(row,bytes=False)),('protocol'if role=='admission'else'admission',row),(role,dict(row,extra=True))]:
     with self.subTest(role=role,badrole=badrole,badrow=badrow),self.assertRaises(ValueError):helper.checked_evidence(root,{},badrole,badrow)
    relative=helper.c.ref(root,rel);self.assertIs(helper.checked_evidence(root,{},role,relative),relative)
   protocol=folder/'protocol.json';body=protocol.read_bytes();row=helper.c.ref(root,'experiments/sota-2026-10-22/audit/epoch42/protocol.json');row['path']=str(protocol)
   other=Path(tmp)/'invented-external.json';other.write_bytes(body);protocol.unlink();protocol.symlink_to(other)
   with self.assertRaises(ValueError):helper.checked_evidence(root,{},'protocol',row)

if __name__=='__main__':unittest.main()
