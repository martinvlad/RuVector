from pathlib import Path
import hashlib,json,os,shutil,tarfile,time
W=Path('/tmp/ruvector-sota-2026-10-22/epoch42-222874558c0b')
SRC=Path('/workspace/ruvector-epoch19-kit-1a1698f9db5')
DEST=Path('/tmp/ruvector-sota-2026-10-22/artifact-relocation/epoch19-kit-1a1698f9db5.tar.gz')
def digest_file(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def snapshot():
 assert SRC.is_dir() and not SRC.is_symlink() and SRC.resolve()==SRC
 rows=[]
 for p in [SRC]+sorted(SRC.rglob('*')):
  s=p.lstat();rel=p.relative_to(SRC).as_posix()
  kind='symlink'if p.is_symlink()else'dir'if p.is_dir()else'file'if p.is_file()else'unsupported'
  assert kind!='unsupported'
  rows.append(dict(path=rel,kind=kind,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,
   inode=s.st_ino,device=s.st_dev,mode=s.st_mode,link=os.readlink(p)if kind=='symlink'else None))
 return rows
def put(p,d):
 b=(json.dumps(d,indent=2)+'\n').encode()
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 dfd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(dfd);os.close(dfd)
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def archive_name(rel):return 'epoch19-kit'if rel=='.'else'epoch19-kit/'+rel
def main():
 assert sorted(os.sched_getaffinity(0))==[0,1]
 assert hashlib.sha256((W/'CAPACITY_RELOCATION_PLAN.v1.json').read_bytes()).hexdigest()=='a0a390a28d77e71bbb281f6d3b4020f985c517ed1471188897317671edb8db34'
 started=time.monotonic();before=shutil.disk_usage('/workspace').free
 put(W/'CAPACITY_RELOCATION_ATTEMPT.v1.json',dict(source=str(SRC),destination=str(DEST),started_unix=time.time(),workspace_free_before=before,source_semantic_decodes=0))
 rows=snapshot();DEST.parent.mkdir(exist_ok=True)
 for r in rows:
  if r['kind']=='file':r['sha256']=digest_file(SRC/r['path'])
 assert [{k:v for k,v in r.items()if k!='sha256'}for r in rows]==snapshot()
 with DEST.open('xb')as target:
  with tarfile.open(fileobj=target,mode='w:gz',compresslevel=1,dereference=False)as archive:
   for r in rows:archive.add(SRC/r['path'],arcname=archive_name(r['path']),recursive=False)
  target.flush();os.fsync(target.fileno())
 dfd=os.open(DEST.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(dfd);os.close(dfd)
 index={archive_name(r['path']):r for r in rows}
 with tarfile.open(DEST,'r:gz')as archive:
  members=archive.getmembers();assert len(members)==len(rows)
  for member in members:
   key=member.name;r=index.pop(key)
   if r['kind']=='file':
    assert member.isfile()or member.islnk();h=hashlib.sha256()
    with archive.extractfile(member)as stream:
     for b in iter(lambda:stream.read(1048576),b''):h.update(b)
    assert h.hexdigest()==r['sha256'] and member.size in (0,r['size'])
   elif r['kind']=='symlink':assert member.issym()and member.linkname==r['link']
   else:assert member.isdir()
  assert not index
 assert [{k:v for k,v in r.items()if k!='sha256'}for r in rows]==snapshot()
 inventory=put(W/'CAPACITY_RELOCATION_PRIVATE_INVENTORY.v1.json',dict(source=str(SRC),files=rows,archive_sha256=digest_file(DEST),archive_bytes=DEST.stat().st_size,all_archived_members_verified=True))
 # The complete, fsynced archive and inventory are verified before this exact removal.
 shutil.rmtree(SRC)
 after=shutil.disk_usage('/workspace').free
 result=dict(epoch=42,status='VERIFIED_REVERSIBLE_OBSOLETE_KIT_RELOCATED',source=str(SRC),archive=str(DEST),archive_sha256=digest_file(DEST),archive_bytes=DEST.stat().st_size,inventory=inventory,entries=len(rows),regular_bytes=sum(r['size']for r in rows if r['kind']=='file'),workspace_free_before=before,workspace_free_after=after,workspace_bytes_reclaimed=after-before,frozen_workspace_minimum_bytes=67108864,capacity_now_passes=after>=67108864,wall_seconds=time.monotonic()-started,all_archived_members_verified=True,source_removed_only_after_verification=True,semantic_decodes=0,model_native_tokenizer_scorer_Gold_Git_calls=0,active_E42_assets_or_source_changed=False,archive_and_private_inventory_not_for_publication=True)
 print(json.dumps(put(W/'CAPACITY_RELOCATION_RESULT.v1.json',result)))
if __name__=='__main__':main()
