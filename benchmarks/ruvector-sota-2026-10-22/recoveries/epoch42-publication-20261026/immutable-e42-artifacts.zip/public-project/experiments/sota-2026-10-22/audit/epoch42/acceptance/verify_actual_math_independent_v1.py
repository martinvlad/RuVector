"""Independent record-only E42 arithmetic. Never imports candidate or scorer code.

Labels are optional and may be supplied only after root's legitimate once-join.
Original archive, features and vault are never inputs to this program.
"""
import argparse
from decimal import Decimal, localcontext
import hashlib
import itertools
import json
import math
from pathlib import Path
import struct

LABELS=('NotMentioned','Entailment','Contradiction')
ARMS=('tasksource_native_two_windows','tasksource_lexical_two_windows','tasksource_source_order_two_windows')
MAP=(1,0,2)
TOL=1e-12

def demand(v,message):
    if not v:raise ValueError(message)

def read(path,expected):
    path=Path(path);data=path.read_bytes()
    demand(hashlib.sha256(data).hexdigest()==expected,'INPUT_SHA256_MISMATCH')
    return json.loads(data),{'path':str(path),'bytes':len(data),'sha256':expected}

def quantile(values,q):
    a=sorted(values);demand(a and 0<=q<=1,'QUANTILE_INPUT')
    at=(len(a)-1)*q;lo=int(at);part=at-lo
    return a[lo]*(1-part)+a[min(lo+1,len(a)-1)]*part

def close(got,want,description):
    demand(type(got)in(int,float)and math.isfinite(got)and abs(got-want)<=TOL,description)

def vector(got,want,description):
    demand(type(got)is list and len(got)==len(want),description)
    for a,b in zip(got,want):close(a,b,description)

def window(logits):
    demand(type(logits)is list and len(logits)==3,'THREE_LOGITS_REQUIRED')
    demand(all(type(v)in(int,float)and math.isfinite(v)and struct.unpack('<f',struct.pack('<f',v))[0]==v for v in logits),'FINITE_LOSSLESS_FP32_LOGITS')
    with localcontext()as ctx:
        ctx.prec=80
        d=[Decimal.from_float(float(v))for v in logits];peak=max(d)
        exponentials=[(v-peak).exp()for v in d];denominator=sum(exponentials)
        original=[v/denominator for v in exponentials]
        probabilities=[original[i]for i in MAP]
        logs=[(d[i]-peak)-denominator.ln()for i in MAP]
        winner=max(range(3),key=lambda i:d[MAP[i]])
        return {'decimal_probabilities':probabilities,'raw_probabilities':[float(v)for v in original],
                'p':[float(v)for v in probabilities],'lp':[float(v)for v in logs],
                'winner':winner,'label':LABELS[winner]}

def derived(two):
    with localcontext()as ctx:
        ctx.prec=80
        p=[(two[0]['decimal_probabilities'][i]+two[1]['decimal_probabilities'][i])/2 for i in range(3)]
        logs=[v.ln()for v in p];winner=max(range(3),key=lambda i:p[i])
        return {'p':[float(v)for v in p],'lp':[float(v)for v in logs],
                'winner':winner,'label':LABELS[winner]}

def distribution(values):
    demand(values and all(math.isfinite(v)and v>=0 for v in values),'NONNEGATIVE_MEASURED_TIMES_REQUIRED')
    return {'N':len(values),'minimum':min(values),'p50':quantile(values,.5),'p95':quantile(values,.95),'maximum':max(values),'sum':math.fsum(values)}

def recompute(raw):
    demand(raw['epoch']==42 and raw['phase']=='dev'and raw['status']=='DEV_FORECASTS_COMPLETE_NO_GOLD'and raw['errors']==[],'COMPLETE_PUBLIC_RAW_REQUIRED')
    cases=raw['cases'];demand(len(cases)==12 and len({r['id']for r in cases})==12,'FIXED12_UNIQUE_CASES')
    values={};timing={};coverage={};all_ids=[];joint=[]
    for arm in ARMS:
        values[arm]={};all_windows=[];coverage[arm]=[]
        for row in cases:
            demand(set(row['window_readouts'])==set(ARMS)and len(row['window_readouts'][arm])==2,'THREE_ARMS_TWO_WINDOWS')
            two=[];ids=[]
            for i,receipt in enumerate(row['window_readouts'][arm]):
                expected=row['id']+'::'+arm+'::window:'+str(i)
                demand(receipt['readout_id']==expected and receipt['model_tag']=='tasksource','EXACT_PHYSICAL_WINDOW_ID')
                actual=window(receipt['raw_native_logits']);two.append(actual);ids.append(expected);all_ids.append(expected)
                vector(receipt['raw_native_probabilities'],actual['raw_probabilities'],'RAW_SOFTMAX_DECIMAL_PARITY')
                vector(receipt['probabilities_N_E_C'],actual['p'],'CANONICAL_SOFTMAX_DECIMAL_PARITY')
                vector(receipt['log_probabilities_N_E_C'],actual['lp'],'STABLE_LOGSOFTMAX_DECIMAL_PARITY')
                demand(receipt['canonical_argmax_index']==actual['winner']and receipt['primary_label']==receipt['argmax_label']==actual['label'],'PHYSICAL_CANONICAL_FIRST_ARGMAX')
                audit=receipt['input_audit'];joint.append(audit['joint_tokens'])
                demand(audit['claim_complete']is True and audit['premise_truncated']is False and 0<audit['joint_tokens']<=512,'FULL_CLAIM_ZERO_CLIP_512')
                demand(audit['full_joint_tokens']==audit['joint_tokens']and audit['full_claim_tokens']==audit['consumed_claim_tokens'],'ACTUAL_FULL_PAIR_TOKEN_PARITY')
                all_windows.append(receipt)
            predicted=derived(two);values[arm][row['id']]=predicted;receipt=row['readouts'][arm]
            vector(receipt['probabilities_N_E_C'],predicted['p'],'DECIMAL_ARITHMETIC_PROBABILITY_MIXTURE')
            vector(receipt['log_probabilities_N_E_C'],predicted['lp'],'DECIMAL_STABLE_MIXTURE_NLL')
            demand(receipt['canonical_argmax_index']==predicted['winner']and receipt['primary_label']==predicted['label'],'DERIVED_CANONICAL_FIRST_ARGMAX')
            demand(receipt['window_readout_ids']==ids and receipt['forecast_id']==row['id']+'::'+arm,'DERIVED_REFERENCE_PARITY')
            demand(receipt['aggregation']=='EQUAL_WEIGHT_ARITHMETIC_PROBABILITY_MIXTURE_TWO_REAL_WINDOWS'and receipt['real_window_outputs_required']==2 and receipt['retrieval_miss_absence_inference']is False,'FROZEN_MIXTURE_NO_ABSENCE_OVERRIDE')
            packed=row['context_windows'][arm];union=set().union(*(set(w['selected_unit_ids'])for w in packed['windows']))
            demand(union==set(packed['union_selected_unit_ids'])and len(packed['windows'])==2,'UNION_SOURCE_UNIT_COVERAGE')
            for w in packed['windows']:
                demand(w['span_splits']==0 and w['premise_truncated']is False and w['selection_is_not_a_proof_of_absence']is True,'WHOLE_SOURCE_UNIT_PACKING')
            cov=packed['union_coverage_audit']
            for prefix in ['numeric_literal','date_pattern']:
                total,retained,omitted=[cov[prefix+'_'+k]for k in ['total','retained','omitted']]
                demand(all(type(v)is int and v>=0 for v in[total,retained,omitted])and retained+omitted==total,'RETAINED_LITERAL_COUNT_ACCOUNTING')
                close(cov[prefix+'_coverage'],retained/total if total else 1.,'LITERAL_RATIO_ONLY_NOT_SEMANTIC_RESCAN')
            coverage[arm].append({'id':row['id'],'document_id':row['document_id'],'union_source_units':len(union),
                'source_units':len(row['source_unit_ids']),'union_unit_fraction':len(union)/len(row['source_unit_ids']),
                'numeric_literal_fraction':cov['numeric_literal_coverage'],'date_pattern_fraction':cov['date_pattern_coverage'],
                'duplicate_windows':packed['duplicate_window_count']})
            for field,part in [('two_window_reader_total_seconds','reader_total_seconds'),('two_window_NNI_forward_seconds','NNI_forward_seconds')]:
                close(receipt['timing'][field],math.fsum(w['timing'][part]for w in row['window_readouts'][arm]),'MEASURED_COMPONENT_SUM')
        timing[arm]={field:distribution([w['timing'][field]for w in all_windows])for field in['pair_tokenization_seconds','NNI_forward_seconds','reader_total_seconds']}
        timing[arm].update({field:distribution([r['readouts'][arm]['timing'][field]for r in cases])for field in['two_window_reader_total_seconds','two_window_NNI_forward_seconds','packing_seconds']})
    demand(len(all_ids)==len(set(all_ids))==72 and set(all_ids)==set(raw['completed_readout_ids'])==set(raw['required_readout_ids']),'ALL72_PHYSICAL_IDS')
    return values,{'physical_readouts_reconstructed':72,'derived_forecasts_reconstructed':36,'numeric_method':'Decimal80 exact-binary-FP32 softmax, then direct arithmetic probability average; float receipts compared absolute1e-12. No scorer/candidate code imported.',
        'all_72_joint_tokens':{'minimum':min(joint),'maximum':max(joint),'truncations':0},'measured_component_latencies':timing,
        'timing_scope':'24physical windows and12derived two-window component sums per arm; shared init/BGE/index/queue and whole resource wall are not publisher/end-to-end latency.',
        'coverage_diagnostics':coverage,'coverage_scope':'Record-level count/ratio/ID internal consistency only. Original text/regex not reread; literal retention is not evidence sufficiency, arithmetic proof, or semantic coverage.'}

def metric(cases,predictions,labels):
    confusion={g:{p:0 for p in LABELS}for g in LABELS};scores=[]
    for row in cases:
        v=predictions[row['id']];gold=labels[row['id']];target=LABELS.index(gold);confusion[gold][v['label']]+=1
        scores.append({'id':row['id'],'document_id':row['document_id'],'correct':int(v['label']==gold),
            'Brier':math.fsum((p-int(j==target))**2 for j,p in enumerate(v['p'])),'NLL':-v['lp'][target]})
    ec={}
    for label in LABELS[1:]:
        support=sum(confusion[label].values());predicted=sum(v[label]for v in confusion.values());tp=confusion[label][label]
        ec[label]={'gold_support':support,'predicted':predicted,'TP':tp,'precision':tp/predicted if predicted else 0.,
            'recall':tp/support if support else None,'f1':2*tp/(support+predicted)if support else None}
    pair=[ec[label]['f1']for label in LABELS[1:]]
    return {'N':len(cases),'correct':sum(v['correct']for v in scores),'accuracy':sum(v['correct']for v in scores)/len(cases),
        'Brier':math.fsum(v['Brier']for v in scores)/len(cases),'NLL':math.fsum(v['NLL']for v in scores)/len(cases),
        'confusion':confusion,'E_C_support':ec,'author_EC_F1_mean':None if None in pair else sum(pair)/2,
        'author_EC_F1_hmean':None if None in pair else 2*math.prod(pair)/sum(pair)if all(pair)else 0.,'scores':scores}

def label_analysis(raw,values,joined):
    cases=raw['cases'];labels=joined['labels'];ids=[r['id']for r in cases]
    demand(joined['epoch']==42 and joined['phase']=='dev'and joined['selected_ids']==ids and set(labels)==set(ids),'EXACT_ONCE_JOINED12_AUTHORIZED_IDENTITY')
    demand(joined['semantic_labels_decoded']==12 and joined['label_reader_calls']==1 and joined['all_labels_decoded_after_forecasts_and_physical_closure']is True and joined['used_confirmation_identities']==[],'COMPLETED_ONCE_LATE_JOIN_ONLY')
    demand(joined['source_plan_sha256']==raw['plan_sha256']and all(type(v)is str and v in LABELS for v in labels.values()),'EXACT_SUPPORTED_RAW_LABELS_NO_REMAP')
    metrics={arm:metric(cases,values[arm],labels)for arm in ARMS};native=metrics[ARMS[0]];gates={};paired={}
    docs=list(dict.fromkeys(r['document_id']for r in cases));demand(len(docs)==4,'FOUR_DOCUMENT_CLUSTERS')
    for arm in ARMS[1:]:
        control=metrics[arm];gates[arm+':correct_gain_at_least2']=native['correct']>=control['correct']+2
        for key in['Brier','NLL']:gates[arm+':'+key+'_nonincrease']=native[key]<=control[key]+TOL
        n={v['id']:v for v in native['scores']};c={v['id']:v for v in control['scores']}
        groups={str(doc):{key:math.fsum(n[r['id']][key]-c[r['id']][key]for r in cases if r['document_id']==doc)/3 for key in['correct','Brier','NLL']}for doc in docs}
        exact={}
        for key in['correct','Brier','NLL']:
            differences=[groups[str(d)][key]for d in docs];draws=[math.fsum(differences[i]for i in selection)/4 for selection in itertools.product(range(4),repeat=4)]
            exact[key]={'native_minus_control':math.fsum(differences)/4,'central95_linear_percentile':[quantile(draws,.025),quantile(draws,.975)],'enumerated_resamples':256}
        paired[arm]={'native_only_correct':sum(n[i]['correct']and not c[i]['correct']for i in ids),
            'control_only_correct':sum(c[i]['correct']and not n[i]['correct']for i in ids),'per_document_mean_differences':groups,
            'exact_four_document_cluster_bootstrap':exact,'leave_one_document_out':{str(doc):{a:{k:v for k,v in metric([r for r in cases if r['document_id']!=doc],values[a],labels).items()if k in['N','correct','accuracy','Brier','NLL']}for a in[ARMS[0],arm]}for doc in docs}}
    return {'metrics':metrics,'scientific_gates':gates,'all_quality_gates_passed':all(gates.values()),'paired_controls':paired,
        'diagnostic_uncertainty_scope':'Exact4^4 document-resampling enumeration, no seed/parameter selection; descriptive exchangeability assumption only. Four clusters and three shared hypotheses do not establish12independent documents. CI/leaveout were not frozen admission gates; no generalization/CONF/official rank inference.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--raw',required=True);p.add_argument('--raw-sha',required=True);p.add_argument('--output',required=True)
    p.add_argument('--joined');p.add_argument('--joined-sha');args=p.parse_args()
    raw,raw_ref=read(args.raw,args.raw_sha);values,analysis=recompute(raw)
    result={'schema_version':1,'epoch':42,'checks_passed':True,'raw':raw_ref,'arithmetic':analysis,'gold_accessed':False,
            'actual_model_tokenizer_native_scorer_or_original_data_calls':0,'source_of_predictions':'Existing completed public72 FP32 logit records only.'}
    if args.joined:
        demand(args.joined_sha is not None,'EXACT_JOINED_SHA_REQUIRED');joined,joined_ref=read(args.joined,args.joined_sha)
        result.update(gold_accessed=True,legitimately_once_decoded_joined_metadata=joined_ref,label_analysis=label_analysis(raw,values,joined))
    else:demand(args.joined_sha is None,'JOINED_PATH_MISSING')
    path=Path(args.output)
    with path.open('x')as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    b=path.read_bytes();print(json.dumps({'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'checks_passed':True,'gold_accessed':result['gold_accessed']}))

if __name__=='__main__':main()
